**To delete a maintenance window**

This example removes a maintenance window.

Command::

  aws ssm delete-maintenance-window --window-id "mw-1a2b3c4d5e6f7g8h9"

Output::

  {
	"WindowId":"mw-1a2b3c4d5e6f7g8h9"
  }
